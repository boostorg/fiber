/// This file is used to create empty library
/// for MSVC Extension.Test project dependency.
/// It is useful to test header files.

//#include <boost/extension/factory_map.hpp>
